# Traducteur de carte Yu-Gi-Oh

Ce projet est une extension web qui traduit les effets de cartes Yu-Gi-Oh lors des duels sur le simulateur [Dueling Nexus](https://duelingnexus.com/home).
L'extension est compatible pour Firefox et pour Chrome.

## Installation

### Firefox
Pour installer l'extension sur Firefox rendez-vous dans : 
```Paramètre -> Extensions et thèmes -> Installer un module depuis un fichier```.

Puis sélectionner le fichier : ```traducteur_de_carte_yu_gi_oh-1.0-an+fx.xpi```.

### Chrome
Pour installer l'extension sur Chrome rendez-vous dans : 
```Paramètre -> Extensions -> Empaqueter l'extension```.

Sélectionner le dossier contenant le code source, puis cliquer sur : ```Empaqueter l'extension```.
